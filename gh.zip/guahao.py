"""挂号抢号辅助工具 —— 主程序

个人本人使用,基于 requests 实现。通过 config.json 驱动,适配不同医院自有系统。

用法:
    python guahao.py            # 读取同目录 config.json
    python guahao.py cfg.json   # 指定配置文件
    python guahao.py --dry-run  # 只发一次测试请求,不真正等待放号时间
"""

from __future__ import annotations

import argparse
import json
import re
import sys
import time
from datetime import datetime, timedelta
from pathlib import Path
from urllib.parse import urljoin

import requests


# ---------- 条件表达式解析 ----------
# 支持形如:
#   $.code==0
#   $.remainNum>0
#   $.data.status=="OK"
#   $.success==true
# 也支持纯文本包含判断(response_contains 由调用方自行处理)

_COMPARISON_RE = re.compile(r'^\$(?P<path>[A-Za-z0-9_.\[\]]*?)\s*(?P<op>==|!=|>=|<=|>|<)\s*(?P<value>.+)$')


def _extract_json_path(data, path: str):
    """从嵌套 dict/list 中按点号路径取值。支持 [index] 下标。"""
    cur = data
    for part in path.replace('[', '.[').split('.'):
        if part == '':
            continue
        if part.startswith('[') and part.endswith(']'):
            idx = int(part[1:-1])
            cur = cur[idx]
        else:
            if isinstance(cur, list):
                cur = cur[int(part)]
            else:
                cur = cur[part]
    return cur


def _coerce(value_str: str):
    """把表达式右边的字面量转成合适的 Python 类型。"""
    value_str = value_str.strip()
    if value_str.lower() == 'true':
        return True
    if value_str.lower() == 'false':
        return False
    if value_str.lower() == 'null':
        return None
    if (value_str.startswith('"') and value_str.endswith('"')) or \
       (value_str.startswith("'") and value_str.endswith("'")):
        return value_str[1:-1]
    if re.match(r'^-?\d+$', value_str):
        return int(value_str)
    if re.match(r'^-?\d+\.\d+$', value_str):
        return float(value_str)
    return value_str


def eval_condition(resp_json, expression: str) -> bool:
    """判断响应 JSON 是否满足条件表达式。"""
    m = _COMPARISON_RE.match(expression)
    if not m:
        # 不是比较表达式,退化成"该路径存在即真"
        try:
            return bool(_extract_json_path(resp_json, expression.lstrip('$')))
        except Exception:
            return False

    try:
        actual = _extract_json_path(resp_json, m['path'])
    except Exception:
        return False

    expected = _coerce(m['value'])
    op = m['op']

    try:
        if op == '==':
            return actual == expected
        if op == '!=':
            return actual != expected
        if op == '>':
            return actual > expected
        if op == '<':
            return actual < expected
        if op == '>=':
            return actual >= expected
        if op == '<=':
            return actual <= expected
    except TypeError:
        # 类型不兼容的比较,尝试字符串比较
        return str(actual) == str(expected) if op == '==' else False
    return False


# ---------- HTTP 会话 ----------
def build_session(cfg: dict) -> requests.Session:
    s = requests.Session()
    auth = cfg.get('auth', {})
    if auth.get('cookie'):
        s.headers['Cookie'] = auth['cookie']
    for k, v in (auth.get('headers') or {}).items():
        s.headers[k] = v
    # 默认 UA,可被 book_request.headers 覆盖
    s.headers.setdefault('User-Agent',
        'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 '
        '(KHTML, like Gecko) Chrome/124.0 Safari/537.36')
    net = cfg.get('network', {})
    if not net.get('verify_ssl', True):
        s.verify = False
    if net.get('proxies'):
        s.proxies.update(net['proxies'])
    return s


# ---------- 请求执行 ----------
def _do_request(session: requests.Session, cfg: dict, base_url: str,
                req_block: dict) -> requests.Response:
    url = urljoin(base_url.rstrip('/') + '/', req_block['path'].lstrip('/'))
    timeout = cfg.get('network', {}).get('timeout_seconds', 10)
    method = req_block.get('method', 'GET').upper()
    headers = req_block.get('headers') or {}
    params = req_block.get('params') or {}
    body = req_block.get('json_body')
    data = req_block.get('data_body')

    return session.request(
        method, url, headers=headers, params=params,
        json=body, data=data, timeout=timeout, allow_redirects=False,
    )


# ---------- 调度:等待放号时间 ----------
def _next_release_time(release_time: str) -> datetime:
    """返回今天或明天最近的 release_time datetime。"""
    now = datetime.now()
    t = datetime.strptime(release_time, '%H:%M:%S').time()
    target = datetime.combine(now.date(), t)
    if target <= now:
        target += timedelta(days=1)
    return target


def wait_until_release(cfg: dict, dry_run: bool) -> datetime:
    sch = cfg['schedule']
    target = _next_release_time(sch['release_time'])

    if dry_run:
        print(f'[dry-run] 跳过等待,目标放号时间本应是 {target:%Y-%m-%d %H:%M:%S}')
        return datetime.now()

    prepare = sch.get('_prepare_seconds', 30)
    wait_point = target - timedelta(seconds=prepare)
    print(f'目标放号时间: {target:%Y-%m-%d %H:%M:%S}')
    print(f'将在 {wait_point:%H:%M:%S} 提前 {prepare}s 进入准备状态...')

    while True:
        now = datetime.now()
        if now >= wait_point:
            break
        remain = (wait_point - now).total_seconds()
        # 大间隔打印,小间隔静默避免刷屏
        if remain > 60:
            print(f'  距离放号还有 {remain/60:.1f} 分钟 ({now:%H:%M:%S})', flush=True)
            time.sleep(min(30, remain - 5))
        elif remain > 0:
            time.sleep(0.5)
        else:
            break

    # 进入准备:忙等 + NTP 级精度对齐
    print('进入对齐阶段,精确等待放号...')
    while datetime.now() < target:
        time.sleep(0.001)

    print(f'放号时刻到达!当前 {datetime.now():%H:%M:%S.%f}')
    return target


# ---------- 主流程 ----------
def run(cfg_path: str, dry_run: bool):
    cfg = json.loads(Path(cfg_path).read_text(encoding='utf-8'))
    base_url = cfg['target']['base_url']
    session = build_session(cfg)

    print('=' * 60)
    print(f'挂号抢号工具  目标: {cfg["target"].get("name","(未命名)")}')
    print(f'Base URL: {base_url}')
    print('=' * 60)

    # 1. 等待放号时间(或 dry-run 直接跳过)
    wait_until_release(cfg, dry_run)

    book_req = cfg['book_request']
    query_req = cfg.get('query_request') or {}
    retry = cfg.get('retry', {})
    max_attempts = retry.get('max_attempts', 30)
    interval = retry.get('interval_ms', 200) / 1000.0

    success_ind = book_req.get('success_indicator') or {}

    # 2. (可选)放号前轮询查询号源是否已出
    if cfg['schedule'].get('_retry_before_release') and query_req and not dry_run:
        avail_expr = (query_req.get('available_indicator') or {}).get('response_json_path')
        print('放号前探测模式:轮询号源...')
        probe_start = datetime.now()
        while datetime.now() < probe_start + timedelta(
                seconds=cfg['schedule'].get('_prepare_seconds', 30) + 30):
            try:
                r = _do_request(session, cfg, base_url, query_req)
                if avail_expr:
                    try:
                        rj = r.json()
                        if eval_condition(rj, avail_expr):
                            print(f'  探测到号源! {datetime.now():%H:%M:%S.%f}')
                            break
                    except Exception:
                        pass
            except requests.RequestException as e:
                print(f'  探测请求异常: {e}')
            time.sleep(cfg['schedule'].get('_retry_interval_ms', 50) / 1000.0)

    # 3. 抢号主循环
    print(f'开始抢号,最大尝试 {max_attempts} 次,间隔 {interval:.3f}s')
    for attempt in range(1, max_attempts + 1):
        t0 = time.time()
        try:
            r = _do_request(session, cfg, base_url, book_req)
            elapsed = (time.time() - t0) * 1000
            ok = True
            reason = ''
            if 'status_code' in success_ind and r.status_code != success_ind['status_code']:
                ok = False
                reason = f'status={r.status_code}'
            if ok and success_ind.get('response_contains'):
                if success_ind['response_contains'] not in r.text:
                    ok = False
                    reason = 'resp_not_contains'
            if ok and success_ind.get('response_json_path'):
                try:
                    rj = r.json()
                    if not eval_condition(rj, success_ind['response_json_path']):
                        ok = False
                        reason = f'condition_false ({success_ind["response_json_path"]})'
                except Exception as e:
                    ok = False
                    reason = f'json_parse_err({e.__class__.__name__})'

            ts = datetime.now().strftime('%H:%M:%S.%f')[:-3]
            if ok:
                print(f'[{ts}] 第{attempt}次 成功! 用时{elapsed:.0f}ms')
                print(f'  响应: {r.text[:300]}')
                print('抢号成功,请尽快完成支付!')
                return 0
            else:
                print(f'[{ts}] 第{attempt}次 失败 ({reason}) 用时{elapsed:.0f}ms')
                if attempt <= 3 or attempt % 10 == 0:
                    print(f'  响应片段: {r.text[:200]}')
        except requests.RequestException as e:
            print(f'  第{attempt}次 请求异常: {e}')

        if attempt < max_attempts:
            time.sleep(interval)

    print('已达到最大尝试次数,未能抢到号源。')
    return 1


def main():
    parser = argparse.ArgumentParser(description='挂号抢号辅助工具(个人使用)')
    parser.add_argument('config', nargs='?', default='config.json',
                        help='配置文件路径,默认 config.json')
    parser.add_argument('--dry-run', action='store_true',
                        help='只发一次测试请求,不等待放号时间')
    args = parser.parse_args()

    cfg_path = args.config
    if not Path(cfg_path).is_absolute():
        # 相对于脚本所在目录
        cfg_path = str(Path(__file__).resolve().parent / cfg_path)
    if not Path(cfg_path).exists():
        print(f'配置文件不存在: {cfg_path}')
        sys.exit(2)

    code = run(cfg_path, args.dry_run)
    sys.exit(code)


if __name__ == '__main__':
    main()