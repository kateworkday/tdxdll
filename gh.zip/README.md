# 挂号抢号辅助工具 使用指南

> 仅用于个人本人挂号,请勿用于倒卖号源等违法用途。

## 一、快速开始

```bash
pip install -r requirements.txt
python guahao.py            # 按 config.json 的放号时间自动抢号
python guahao.py --dry-run  # 调试模式,立即发一次请求,不等待
python guahao.py mycfg.json # 指定其他配置
```

## 二、如何抓取真实请求填入 config.json

核心思路:在浏览器里**手动完成一次挂号流程**,用开发者工具(F12 → Network)抓包,把关键请求复制到配置文件。

### 步骤

1. 用 Chrome/Edge 打开医院挂号网站,**先登录**好。
2. 按 `F12` 打开开发者工具,切到 **Network** 面板,勾选 **Preserve log**。
3. 手动走一遍"选医生 → 选日期 → 点预约 → 选就诊人 → 确认"的流程。
4. 在 Network 里找到**真正提交挂号的那一条请求**(通常是最后一步的 POST)。
5. 把以下信息抄进 `config.json` 的 `book_request`:

| 配置项 | 对应抓包内容 |
|---|---|
| `method` | 请求方法(GET/POST) |
| `path` | URL 中 base_url 之后的部分 |
| `headers` | Request Headers |
| `params` | URL 上的查询参数 |
| `json_body` | 请求体(JSON 格式时) |
| `data_body` | 请求体(表单格式时,需自行改用此字段) |

6. 登录态:最简单方式 —— 在 Request Headers 里找到 `Cookie:` 整行,复制到 `auth.cookie`。

### 判断成功

在 Network 里看那条请求的 **Response**,找一个能区分"成功/失败"的字段,填到 `success_indicator`:

- HTTP 状态码:`"status_code": 200`
- 响应包含某文字:`"response_contains": "预约成功"`
- 响应 JSON 字段判断:`"response_json_path": "$.code==0"` 或 `$.data.success==true`

## 三、放号时间配置

`schedule.release_time` 设成医院规定的放号时刻(如 `"08:00:00"`)。工具会:

1. 提前 `prepare_seconds`(默认 60s)进入准备状态
2. 精确对齐到放号时刻(毫秒级忙等)
3. 立即连续发起抢号请求,最多 `retry.max_attempts` 次

## 四、(可选)号源探测

如果医院系统支持"查询余号"接口,可在 `query_request` 填入查询请求 + `available_indicator`。工具会在放号前持续轮询,一旦探测到号源立刻抢。这比纯定时更稳。

## 五、条件表达式语法

`response_json_path` / `available_indicator.response_json_path` 支持:

| 语法 | 含义 |
|---|---|
| `$.code==0` | 响应 JSON 的 `code` 字段等于 0 |
| `$.remainNum>0` | `remainNum` 大于 0 |
| `$.data.status=="OK"` | 嵌套字段字符串比较 |
| `$.success==true` | 布尔判断 |
| `$.msg!="无号"` | 不等于 |
| `$.items[0].available==1` | 数组下标 |

## 六、常见问题

- **登录态过期**:Cookie 一般几小时~一天就失效,抢号前重新登录刷新 Cookie。
- **请求被拒/风控**:可适当增大 `retry.interval_ms`,或在 `auth.headers` 加 `Referer`、`Origin` 等头模拟正常浏览器。
- **时间不准**:本机时间要准,建议开启系统自动校时(NTP)。
- **HTTPS 证书问题**:内网测试可临时把 `network.verify_ssl` 设 `false`。